Hello!

If you didn't take the "Develop Websites and Components in AEM" course,
you can install the package from the 0-previous-course-work folder
to catch back up with where this course begins.

If you have any troubles, please leave a comment in the course discussion.

Thanks!

-Tyler Maynard